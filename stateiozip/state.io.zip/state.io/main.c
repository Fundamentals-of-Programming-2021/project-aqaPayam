#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
SDL_Event event;
struct block
{
    int xpos;
    int ypos;
    int index;   //-1 yani khali baghie raghama motealegh be rangesh
    int number_soldier;
};
struct soldier
{
    double x;
    double y;
    double vx;
    double vy;
    int num_dest_block;
    int num_beg_block;
    int destx;
    int desty;
    struct soldier * next;
};
struct warstatus
{
    int att;
    int def;
    int num_soldier;
    int counter;
    struct soldier * head;
};
struct block all_block[45];
int xCursor=0,yCursor=0;
Mix_Music *music=NULL;
SDL_Window *window=NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *texture=NULL;
SDL_Rect texture_rect={.x=0,.y=0,.w=1920,.h=1080};
SDL_Surface *image=NULL;
char name[200]=" ";
char name_used_in_menu[200]="welcome";
char temp_of_function_numberToString[10]="";
const int FPS = 60;
const int SCREEN_WIDTH = 1920;
const int SCREEN_HEIGHT = 1080;
bool game_is_running=true;
bool sound=true;
int which_block_clicked(struct block arr_of_valid_block[],int num_of_valiv_block,SDL_Event ev)
{
    if(ev.type==SDL_MOUSEBUTTONUP)
    {
        SDL_GetMouseState(&xCursor, &yCursor);
        for (int i = 0; i < num_of_valiv_block; i++)
            if( (arr_of_valid_block[i].xpos - xCursor <= 100 && -100 <= arr_of_valid_block[i].xpos - xCursor)  &&
                    (arr_of_valid_block[i].ypos - yCursor <= 100 && -100 <= arr_of_valid_block[i].ypos - yCursor ))
                return i;
    }
    return -1;
}
void strrev(char *str1)
{
    // declare variable
    int i, len, temp;
    len = strlen(str1); // use strlen() to get the length of str string

    // use for loop to iterate the string
    for (i = 0; i < len/2; i++)
    {
        // temp variable use to temporary hold the string
        temp = str1[i];
        str1[i] = str1[len - i - 1];
        str1[len - i - 1] = temp;
    }
}
int number_to_string(int num) //return chand raghamie va string mire too temp_of_function_numberToString[10]
{
    if (num==0)
    {
        temp_of_function_numberToString[0]='0';
        temp_of_function_numberToString[1]='\0';
        return 1;
    }
    int counter = 0;
    while( num > 0 )
    {
     temp_of_function_numberToString[counter]=(int)(num%10+48);
     counter++;
     num/=10;
    }
    temp_of_function_numberToString[counter]='\0';
    strrev(temp_of_function_numberToString);
    return counter;
}
void soundplay(SDL_Event ev)
{
    SDL_GetMouseState(&xCursor,&yCursor);
        if(ev.type==SDL_MOUSEBUTTONDOWN && xCursor<=1828 && xCursor>=1720 &&yCursor<=138 && yCursor>=30)
        {
            sound=!sound;
        }
}
void showcursorandsound()
{
    if(sound)
    {
        SDL_Surface *img = SDL_LoadBMP("soundicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
        SDL_FreeSurface(img);
        SDL_DestroyTexture(texture_hitler);
    }
    else
    {
        SDL_Surface *img = SDL_LoadBMP("muteicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
        SDL_FreeSurface(img);
        SDL_DestroyTexture(texture_hitler);
    }
    SDL_GetMouseState(&xCursor,&yCursor);
    SDL_Surface *image_cursor= SDL_LoadBMP("cursor.bmp");
    if(!image_cursor)
        printf("ridi dar cursor %s",SDL_GetError());
    SDL_Rect cursor_place={.x=xCursor-50,.y=yCursor-40,.w=100,.h=80};
    SDL_Texture *texture_cursor= SDL_CreateTextureFromSurface(renderer,image_cursor);
    SDL_RenderCopy(renderer,texture_cursor,NULL,&cursor_place);
    if (!sound)
        Mix_PauseMusic();
    else
        Mix_ResumeMusic();
    SDL_FreeSurface(image_cursor);
    SDL_DestroyTexture(texture_cursor);
}
void show_text(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );

    SDL_FreeSurface( textSurface );

    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
    TTF_CloseFont(gFont);
}
void txtRGBA(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    roundedBoxRGBA(renderer,x-50,y-50,x+450,y+150,90,61,61,61,255);
    roundedBoxRGBA(renderer,x,y,x+400,y+100,90,78,78,78,255);
    x+=75;
    y+=20;
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );
    SDL_FreeSurface( textSurface );

    if (xCursor >= x && xCursor<=x+mWidth && yCursor>=y && yCursor<=y+mHeight)
    {
        SDL_Surface *image_hitler= SDL_LoadBMP("hitler.bmp");
        if(!image_hitler)
            printf("ridi dar hitler %s",SDL_GetError());
        SDL_Rect hitler_place={.x=900,.y=y-30,.w=320,.h=180};
        SDL_Texture *texture_hitler= SDL_CreateTextureFromSurface(renderer,image_hitler);
        SDL_RenderCopy(renderer,texture_hitler,NULL,&hitler_place);
        SDL_FreeSurface(image_hitler);
        SDL_DestroyTexture(texture_hitler);
    }
    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
    TTF_CloseFont(gFont);

}
void check_exit_game(SDL_Event ev)
{
    const SDL_MessageBoxButtonData buttons[] = {
            { /* .flags, .buttonid, .text */        0, 0, "YES" },
            { SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 1, "NO" }
    };
    const SDL_MessageBoxColorScheme colorScheme = {
            { /* .colors (.r, .g, .b) */
                    /* [SDL_MESSAGEBOX_COLOR_BACKGROUND] */
                    { 50,   50,   50 },
                    /* [SDL_MESSAGEBOX_COLOR_TEXT] */
                    {   255, 255,   255 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BORDER] */
                    { 0,   0,   0 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND] */
                    {   0, 0, 200 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED] */
                    { 255,   0, 0 }
            }
    };
    const SDL_MessageBoxData messageboxdata = {
            SDL_MESSAGEBOX_INFORMATION, /* .flags */
            NULL, /* .window */
            "EXIT", /* .title */
            "Are you sure you want to exit ?", /* .message */
            SDL_arraysize(buttons), /* .numbuttons */
            buttons, /* .buttons */
            &colorScheme /* .colorScheme */
    };
    int buttonid=-1;
        if (ev.type==SDL_QUIT)
        {
            SDL_ShowMessageBox(&messageboxdata, &buttonid);
            if(buttonid==0)
                game_is_running=false;
        }
        else
        if (ev.type==SDL_KEYUP && ev.key.keysym.sym==SDLK_ESCAPE)
        {
            SDL_ShowMessageBox(&messageboxdata, &buttonid);
            if(buttonid==0)
                game_is_running=false;
        }

}
uint32_t color(int r,int g, int b, int a){return    ( (a << 24) + (b<< 16) + (g << 8) + r) ;}
bool is_ok_to_run_game()
{
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER |SDL_INIT_AUDIO) < 0)
    {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return false;
    }
    return true;
}
void render_blocks(int num_block,uint32_t arr[],struct block block[],SDL_Texture *block_khali,SDL_Texture *block_por)
{
    for(int i=0;i<num_block;i++)
    {
        if (block[i].index==-1)
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            SDL_RenderCopy(renderer,block_khali,NULL,&rect);
            if(number_to_string(block[i].number_soldier)==1)
                show_text(renderer,block[i].xpos-15,block[i].ypos+10,temp_of_function_numberToString,40,0,255,0,255);
            else if(number_to_string(block[i].number_soldier)==2)
                show_text(renderer,block[i].xpos-25,block[i].ypos+10,temp_of_function_numberToString,40,0,0,255,255);
            else if(number_to_string(block[i].number_soldier)==3)
                show_text(renderer,block[i].xpos-35,block[i].ypos+10,temp_of_function_numberToString,40,255,0,0,255);
        }
        else
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            filledCircleColor(renderer, block[i].xpos, block[i].ypos, 100, arr[block[i].index]);
            SDL_RenderCopy(renderer,block_por,NULL,&rect);
            if(number_to_string(block[i].number_soldier)==1)
                show_text(renderer,block[i].xpos-15,block[i].ypos+5,temp_of_function_numberToString,50,0,255,0,255);
            else if(number_to_string(block[i].number_soldier)==2)
                show_text(renderer,block[i].xpos-30,block[i].ypos+5,temp_of_function_numberToString,50,0,0,255,255);
            else if(number_to_string(block[i].number_soldier)==3)
                show_text(renderer,block[i].xpos-44,block[i].ypos+5,temp_of_function_numberToString,50,255,0,0,255);

        }
    }
}
void make_randomcolor(uint32_t arr[],int n)
{
    time_t t;
    srand((unsigned) time(&t));
    for( int i = 0 ; i < n ; i++ )
    {
        int r,g,b;
        r=rand() % 256;
        g=rand() % 256;
        b=rand() % 256;
        arr[i]= color(r,g,b,255);
    }
}
bool click_new_game(SDL_Event ev)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    if(ev.type==SDL_MOUSEBUTTONDOWN)
    {
        if(xCursor >= 1375 && xCursor <=1375+276 && yCursor>=270 && yCursor<=339 )
        {
            return true;
        }
    }
    return false;
}
void render_soldier(struct warstatus war[],int number_of_war,SDL_Texture *texttemp,uint32_t arr_color[])
{
//    SDL_Rect texture_soldier={.x=500,.y=500,.w=100,.h=80};
//    SDL_RenderCopy(renderer,texttemp,NULL,&texture_soldier);
    for(int i=0;i<number_of_war;i++)
    {
        struct soldier * current = war[i].head;
        while(current->next!=NULL)
        {
            SDL_Rect texture_soldier={.x=current->x-50,.y=current->y-40,.w=100,.h=80};
            SDL_RenderCopy(renderer,texttemp,NULL,&texture_soldier);
            filledCircleColor(renderer,current->x,current->y,15,arr_color[current->num_beg_block]);
            current=current->next;
        }
    }
}
char inputs_string(SDL_Event ev)
{
    char ch;
    if(ev.type==SDL_KEYUP)
    {
        ch = (char)ev.key.keysym.sym;
        return ch;
    }
}
void generate_one_soldier_end_of_list(struct soldier * head,struct block* att,struct block def,int number_of_dest_block,int number_of_beg_block)
{
    struct soldier * current = head;
    while(current->next!=NULL)
    {
        current=current->next;
    }
    att->number_soldier-=1;
    current->next=(struct soldier*)malloc(sizeof(struct soldier));
    current->x=att->xpos;
    current->y=att->ypos;
    current->vx=(def.xpos-att->xpos)/(double)40;
    current->vy=(def.ypos-att->ypos)/(double)40;
    current->destx=def.xpos;
    current->desty=def.ypos;
    current->num_dest_block=number_of_dest_block;
    current->num_beg_block=number_of_beg_block;
    current->next->next=NULL;
}
bool is_same_soldier(struct soldier a,struct soldier b)
{
    if(a.x==b.x && a.y==b.y && a.vx==b.vx && a.vy==b.vy)
        return true;
    else
        return false;
}
int delete_soldier(struct soldier dest_for_delete,struct soldier ** head)
{
    struct  soldier *current = (*head);
    if (is_same_soldier(*current,dest_for_delete))
    {
        (*head) = (*head)->next;
        return 1;
    }
    while(current->next!=NULL)
    {
        if (is_same_soldier(*(current->next),dest_for_delete))
        {
            current->next = current->next->next;
            return 1;
        }
        current=current->next;
    }
    return 0;//in sarbaz vojood nadasht
}
void moving_soldiers(struct warstatus war[],struct block arr_block[])
{
    for(int i=0;i<100;i++)
    {
        struct soldier * current= war[i].head;
        while(current->next!=NULL)
        {
            current->x +=current->vx;
            current->y +=current->vy;

            if( current->x  - current->destx <80
            &&  -80 < current->x  - current->destx
            &&  current->y  - current->desty <80
                &&    -80 < current->y  - current->desty
                    )
            {
                if (arr_block[current->num_dest_block].index==arr_block[current->num_beg_block].index)
                  arr_block[current->num_dest_block].number_soldier += 1;
                else
                {
                    if (arr_block[current->num_dest_block].number_soldier == 0 )
                    {
                        arr_block[current->num_dest_block].index=arr_block[current->num_beg_block].index;
                        arr_block[current->num_dest_block].number_soldier = 1;
                    }
                    else
                        arr_block[current->num_dest_block].number_soldier -= 1;
                }
                delete_soldier(*current,&war[i].head);
            }
            current=current->next;
        }
    }
}
void generate_all_wars_soldiers(struct warstatus war[],int number_of_wars,struct block arr_of_blocks[])
{
    for(int i=0;i<number_of_wars;i++)
    {
        if( arr_of_blocks[war[i].att].number_soldier == 0)
        {
            war[i].num_soldier=0;
        }
        if (war[i].counter < war[i].num_soldier)
        {
            generate_one_soldier_end_of_list(war[i].head,&arr_of_blocks[war[i].att],arr_of_blocks[war[i].def],war[i].def,war[i].att);
            war[i].counter+=1;
        }
    }
}
 int map()
{
    struct warstatus wars[100000];
    for(int i=0;i<100000;i++)
       wars[i].head=(struct soldier*)malloc(sizeof(struct soldier));
    for(int i=0;i<100000;i++)
        wars[i].head->next=NULL;
    int number_of_attack=0;

    int blockclicked1=-1;
    int blockclicked2=-1;
    bool is_in_war=false;

    for (int j=0;j<5;j++)
    {
        for (int i = 0; i < 9; i++)
        {
            all_block[j * 9 + i].xpos = 160 + i * 200;
            all_block[j * 9 + i].ypos = 110 + j * 200;
            all_block[j * 9 + i].index=-1;
            all_block[j * 9 + i].number_soldier=20;
        }
    }
    int number_of_block,number_of_player;
    scanf("%d %d",&number_of_block,&number_of_player);
    uint32_t arr_of_colors[number_of_player];
    struct block arr_of_block[number_of_block];
    make_randomcolor(arr_of_colors,number_of_player);
    {
        time_t t;
        int random_numbers[number_of_block];
        for(int i=0;i<number_of_block;i++)
            random_numbers[i]=-1;
        int count =0;
        srand((unsigned) time(&t));
        while(count <number_of_block) {
            int randNum =rand()%45;
            if (randNum==8)
                continue;
            bool found =false;
            for (int i = 0; i < count; i++) {
                if(random_numbers[i] ==randNum) {
                    found =true;
                    break;
                }
            }
            if(!found) {
                random_numbers[count] =randNum;
                count++;
            }
        }

        for(int i=0;i<number_of_block;i++) {
            arr_of_block[i] = all_block[random_numbers[i]];
            if (i < number_of_player)
                arr_of_block[i].index=i;
        }
//            printf("%d ",random_numbers[i]);


    }  //inja miad arr_of_block ro random tarif mikone az all block
    ///berim hala karaye rendering
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    music = Mix_LoadMUS("music_war2.mp3");
        if (!is_ok_to_run_game())
        return -1;
    window = SDL_CreateWindow("game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("map_war2.bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);

    SDL_Surface *image_block_por = SDL_LoadBMP("block_por.bmp");
    if (!image_block_por)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_block_por = SDL_CreateTextureFromSurface(renderer, image_block_por);

    SDL_Surface *image_block_khali = SDL_LoadBMP("block_khali.bmp");
    if (!image_block_khali)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_block_khali = SDL_CreateTextureFromSurface(renderer, image_block_khali);

    SDL_Surface *image_soldier = SDL_LoadBMP("bf4soldier.bmp");
    if (!image_soldier)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_soldier = SDL_CreateTextureFromSurface(renderer, image_soldier);

    Mix_PlayMusic(music,-1);
    long long counterFPS=0;
    while (game_is_running)
    {
        counterFPS++;
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        SDL_ShowCursor(SDL_DISABLE);
        render_blocks(number_of_block,arr_of_colors,arr_of_block,texture_block_khali,texture_block_por);
        while(SDL_PollEvent(&event))
        {
            blockclicked2=which_block_clicked(arr_of_block,number_of_block,event);
            soundplay(event);
            check_exit_game(event);
        }
        render_soldier(wars,number_of_attack,texture_soldier,arr_of_colors);
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
        moving_soldiers(wars,arr_of_block);
        if(counterFPS%120==0)
        {
            for (int i = 0; i < number_of_block; i++)
                if (arr_of_block[i].index!= -1  && arr_of_block[i].number_soldier<50)
                    arr_of_block[i].number_soldier++;
        }
        if(counterFPS%10==0)
        {
            generate_all_wars_soldiers(wars,number_of_attack,arr_of_block);
        }
        if(blockclicked2!=-1)
        {
            if(blockclicked1==-1)
            {
                if(arr_of_block[blockclicked2].index==-1)
                    blockclicked2=-1;
                else
                {
                    blockclicked1 = blockclicked2;
                    blockclicked2 = -1;
                }
            }
            else  //bayad jang start beshe
            {
                if(blockclicked2!=blockclicked1)
                {
                    wars[number_of_attack].def = blockclicked2;
                    wars[number_of_attack].att = blockclicked1;
                    wars[number_of_attack].num_soldier = arr_of_block[blockclicked1].number_soldier;
                    wars[number_of_attack].counter = 0;
                    number_of_attack++;
                }
                blockclicked2=-1;
                blockclicked1=-1;
            }
        }
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    music=NULL;
    Mix_Quit();
    SDL_Quit();
}
int menu() {
    strcat(name_used_in_menu,name);
    TTF_Init();
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    music= Mix_LoadMUS("music.mp3");
    if (!is_ok_to_run_game())
        return -1;
    window = SDL_CreateWindow("menu", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("menu .bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);
    Mix_PlayMusic(music,-1);
    while (game_is_running) {
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        show_text(renderer,0,0,name_used_in_menu,60,255,0,0,255);
        txtRGBA(renderer, 1300, 200 + 50, "NEW GAME", 50, 160, 13, 10, 255);
        txtRGBA(renderer, 1300, 440 + 50, "CONTINUE", 50, 160, 13, 10, 255);
        txtRGBA(renderer, 1300, 680 + 50, " RANKING", 50, 160, 13, 10, 255);
        while(SDL_PollEvent(&event))
        {
            if(click_new_game(event))
            {
                SDL_DestroyRenderer(renderer);
                SDL_DestroyWindow(window);
                SDL_DestroyTexture(texture);
                SDL_FreeSurface(image);
                Mix_FreeMusic(music);
                window = NULL;
                renderer = NULL;
                texture=NULL;
                image=NULL;
                music=NULL;
                map();
            }
            soundplay(event);
            check_exit_game(event);
        }
        SDL_ShowCursor(SDL_DISABLE);
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    music=NULL;
    Mix_Quit();
    SDL_Quit();
}
int first_page()
{
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    music= Mix_LoadMUS("music_first.mp3");
    if (!is_ok_to_run_game())
        return -1;
    window = SDL_CreateWindow("HELLO", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("bf4.bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);

    SDL_Surface *imagegame = SDL_LoadBMP("gamename.bmp");
    if (!imagegame)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texturegame = SDL_CreateTextureFromSurface(renderer, imagegame);
    int tool=imagegame->w / 4;
    int arz=imagegame->h  / 4;
    int temp99=0,temp98=0;
    int centerx=960;
    int centery=650;
    Mix_PlayMusic(music,-1);
    SDL_Rect temp_rect;
    while(tool < imagegame->w /2 && game_is_running)
    {
        SDL_ShowCursor(SDL_DISABLE);
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        show_text(renderer,30,30,"LOADING PLEASE WAIT ..",60,0,0,0,255);
        temp_rect.x=centerx-tool/2;
        temp_rect.y=centery-arz/2;
        temp_rect.w=tool;
        temp_rect.h=arz;
        tool+=1;
        arz+=1;
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        while(SDL_PollEvent(&event))
        {
            soundplay(event);
            check_exit_game(event);
        }
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_RenderClear(renderer);
    }   //loading aval
    while(game_is_running && temp99<255)
    {
        SDL_ShowCursor(SDL_DISABLE);
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        show_text(renderer, 30, 30, "PLEASE ENTER YOUR NAME THEN PRESS ENTER :", 40, 40, 2, 90, temp99);
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        SDL_ShowCursor(SDL_DISABLE);

        while(SDL_PollEvent(&event))
        {
            soundplay(event);
            check_exit_game(event);
        }

        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_RenderClear(renderer);
        temp99+=5;
    }  //neveshtan enter name
    while(game_is_running)
    {
        SDL_ShowCursor(SDL_DISABLE);
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        show_text(renderer, 30, 30, "PLEASE ENTER YOUR NAME THEN PRESS ENTER :", 40, 40, 2, 90, 255);
        show_text(renderer,50,150,name,40,0,0,0,255);
        while(SDL_PollEvent(&event))
        {
            soundplay(event);
            check_exit_game(event);
            char ch=inputs_string(event);
            if(('a'<=ch && ch <= 'z') || ch==' ')
                strncat(name,&ch,1);
            if(ch==SDLK_BACKSPACE && strlen(name)>1)
                name[strlen(name)-1]='\0';
            if(ch==SDLK_RETURN)
            {
                printf("\n%s",name);
                SDL_DestroyRenderer(renderer);
                SDL_DestroyWindow(window);
                SDL_DestroyTexture(texture);
                SDL_FreeSurface(image);
                Mix_FreeMusic(music);
                window = NULL;
                renderer = NULL;
                texture=NULL;
                image=NULL;
                music=NULL;
                menu();
            }
            event.key.keysym.sym = NULL;
            event.type = NULL;
        }
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    Mix_Quit();
    SDL_Quit();
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    music=NULL;
}
int main()
{
   //first_page();
   //menu();
   map();
    return 0;
}