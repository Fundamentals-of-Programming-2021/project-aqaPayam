//
// Created by payam on 1/31/22.
//

#ifndef STATE_IO_FUNCTION_H
#define STATE_IO_FUNCTION_H

#endif //STATE_IO_FUNCTION_H

void soundplay(SDL_Event ev)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    if(ev.type==SDL_MOUSEBUTTONDOWN && xCursor<=1828 && xCursor>=1720 &&yCursor<=138 && yCursor>=30)
    {
        sound=!sound;
    }
}
void showcursorandsound()
{
    if(sound)
    {
        SDL_Surface *img = SDL_LoadBMP("soundicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
        SDL_FreeSurface(img);
        SDL_DestroyTexture(texture_hitler);
    }
    else
    {
        SDL_Surface *img = SDL_LoadBMP("muteicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
        SDL_FreeSurface(img);
        SDL_DestroyTexture(texture_hitler);
    }
    SDL_GetMouseState(&xCursor,&yCursor);
    SDL_Surface *image_cursor= SDL_LoadBMP("cursor.bmp");
    if(!image_cursor)
        printf("ridi dar cursor %s",SDL_GetError());
    SDL_Rect cursor_place={.x=xCursor-50,.y=yCursor-40,.w=100,.h=80};
    SDL_Texture *texture_cursor= SDL_CreateTextureFromSurface(renderer,image_cursor);
    SDL_RenderCopy(renderer,texture_cursor,NULL,&cursor_place);
    if (!sound)
        Mix_PauseMusic();
    else
        Mix_ResumeMusic();
    SDL_FreeSurface(image_cursor);
    SDL_DestroyTexture(texture_cursor);
}
void show_text(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );

    SDL_FreeSurface( textSurface );

    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
    TTF_CloseFont(gFont);
}
void txtRGBA(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    roundedBoxRGBA(renderer,x-50,y-50,x+450,y+150,90,61,61,61,255);
    roundedBoxRGBA(renderer,x,y,x+400,y+100,90,78,78,78,255);
    x+=75;
    y+=20;
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );
    SDL_FreeSurface( textSurface );

    if (xCursor >= x && xCursor<=x+mWidth && yCursor>=y && yCursor<=y+mHeight)
    {
        SDL_Surface *image_hitler= SDL_LoadBMP("hitler.bmp");
        if(!image_hitler)
            printf("ridi dar hitler %s",SDL_GetError());
        SDL_Rect hitler_place={.x=900,.y=y-30,.w=320,.h=180};
        SDL_Texture *texture_hitler= SDL_CreateTextureFromSurface(renderer,image_hitler);
        SDL_RenderCopy(renderer,texture_hitler,NULL,&hitler_place);
        SDL_FreeSurface(image_hitler);
        SDL_DestroyTexture(texture_hitler);
    }
    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
    TTF_CloseFont(gFont);

}
void check_exit_game(SDL_Event ev)
{
    const SDL_MessageBoxButtonData buttons[] = {
            { /* .flags, .buttonid, .text */        0, 0, "YES" },
            { SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 1, "NO" }
    };
    const SDL_MessageBoxColorScheme colorScheme = {
            { /* .colors (.r, .g, .b) */
                    /* [SDL_MESSAGEBOX_COLOR_BACKGROUND] */
                    { 50,   50,   50 },
                    /* [SDL_MESSAGEBOX_COLOR_TEXT] */
                    {   255, 255,   255 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BORDER] */
                    { 0,   0,   0 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND] */
                    {   0, 0, 200 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED] */
                    { 255,   0, 0 }
            }
    };
    const SDL_MessageBoxData messageboxdata = {
            SDL_MESSAGEBOX_INFORMATION, /* .flags */
            NULL, /* .window */
            "EXIT", /* .title */
            "Are you sure you want to exit ?", /* .message */
            SDL_arraysize(buttons), /* .numbuttons */
            buttons, /* .buttons */
            &colorScheme /* .colorScheme */
    };
    int buttonid=-1;
    if (ev.type==SDL_QUIT)
    {
        SDL_ShowMessageBox(&messageboxdata, &buttonid);
        if(buttonid==0)
            game_is_running=false;
    }
    else
    if (ev.type==SDL_KEYUP && ev.key.keysym.sym==SDLK_ESCAPE)
    {
        SDL_ShowMessageBox(&messageboxdata, &buttonid);
        if(buttonid==0)
            game_is_running=false;
    }

}
uint32_t color(int r,int g, int b, int a){return    ( (a << 24) + (b<< 16) + (g << 8) + r) ;}
bool is_ok_to_run_game()
{
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER |SDL_INIT_AUDIO) < 0)
    {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return false;
    }
    return true;
}
void render_blocks(int num_block,uint32_t arr[],struct block block[],SDL_Texture *block_khali,SDL_Texture *block_por)
{
    for(int i=0;i<num_block;i++)
    {
        if (block[i].index==-1)
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            SDL_RenderCopy(renderer,block_khali,NULL,&rect);
        }
        else
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            filledCircleColor(renderer, block[i].xpos, block[i].ypos, 100, arr[block[i].index]);
            SDL_RenderCopy(renderer,block_por,NULL,&rect);
            // filledCircleColor(renderer, block[i].xpos, block[i].ypos, 90, color(150, 150, 150, 255));
        }
    }
}
void make_randomcolor(uint32_t arr[],int n)
{
    time_t t;
    srand((unsigned) time(&t));
    for( int i = 0 ; i < n ; i++ )
    {
        int r,g,b;
        r=rand() % 256;
        g=rand() % 256;
        b=rand() % 256;
        arr[i]= color(r,g,b,255);
    }
}
bool click_new_game(SDL_Event ev)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    if(ev.type==SDL_MOUSEBUTTONDOWN)
    {
        if(xCursor >= 1375 && xCursor <=1375+276 && yCursor>=270 && yCursor<=339 )
        {
            return true;
        }
    }
    return false;
}