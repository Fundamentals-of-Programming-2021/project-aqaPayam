//
// Created by payam on 2/3/22.
//

#ifndef STATE_IO_FUNCTIONS_H


#define STATE_IO_FUNCTIONS_H


#endif //STATE_IO_FUNCTIONS_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#define max_sarbaz 30
#define NUM_POTOION 12
#define NUM_WAR 100
bool your_potion=false;
bool ai_potion=false;
int fps_potion[NUM_POTOION]={0};
double Vsoldier=10;
uint32_t color(int r,int g, int b, int a){return    ( (a << 24) + (b<< 16) + (g << 8) + r) ;}
uint32_t clr[10];
void declareclr()
{
    clr[0] = color(0, 0, 0, 255);
    clr[1] = color(0, 255, 0, 255);
    clr[2] = color(0, 0, 255, 255);
    clr[3] = color(255, 0, 255, 255);
    clr[4] = color(255, 120, 0, 255);
    clr[5] = color(255, 255, 0, 255);
    clr[6] = color(255, 0, 0, 255);
    clr[7] = color(255, 255, 255, 255);
    clr[8] = color(0, 255, 255, 255);
    clr[9] = color(100, 100, 100, 255);
}
struct potion
{
    int x;
    int y;
    bool exist;
    bool runnig;
    int index;
};
struct axis
{
    int x;
    int y;
};
SDL_Event event;
struct block
{
    bool nolimit;
    bool fastblock;
    int xpos;
    int ypos;
    int index;   //-1 yani khali baghie raghama motealegh be rangesh
    int number_soldier;
    int number_soldier2;
};
struct soldier
{
    double x;
    double y;
    double vx;
    double vy;
    int num_dest_block;
    int num_beg_block;
    int destx;
    int desty;
    int index;
    bool fast_run;
    bool stop;
    struct soldier * next;
};
struct warstatus
{
    int att;
    int def;
    int num_soldier;
    int counter;
    struct soldier * head;
};
struct block all_block[45];
int xCursor=0,yCursor=0;
Mix_Music *music=NULL;
SDL_Window *window=NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *texture=NULL;
SDL_Rect texture_rect={.x=0,.y=0,.w=1920,.h=1080};
SDL_Surface *image=NULL;
char name_used_in_menu[200]="welcome";
char temp_of_function_numberToString[10]="";
const int FPS = 60;
const int SCREEN_WIDTH = 1920;
const int SCREEN_HEIGHT = 1080;
bool game_is_running=true;
bool sound=true;

int which_block_clicked(struct block arr_of_valid_block[],int num_of_valiv_block,SDL_Event ev)
{
    if(ev.type==SDL_MOUSEBUTTONUP)
    {
        SDL_GetMouseState(&xCursor, &yCursor);
        for (int i = 0; i < num_of_valiv_block; i++)
            if( (arr_of_valid_block[i].xpos - xCursor <= 100 && -100 <= arr_of_valid_block[i].xpos - xCursor)  &&
                (arr_of_valid_block[i].ypos - yCursor <= 100 && -100 <= arr_of_valid_block[i].ypos - yCursor ))
                return i;
    }
    return -1;
}
void strrev(char *str1)
{
    // declare variable
    int i, len, temp;
    len = strlen(str1); // use strlen() to get the length of str string

    // use for loop to iterate the string
    for (i = 0; i < len/2; i++)
    {
        // temp variable use to temporary hold the string
        temp = str1[i];
        str1[i] = str1[len - i - 1];
        str1[len - i - 1] = temp;
    }
}
int number_to_string(int num) //return chand raghamie va string mire too temp_of_function_numberToString[10]
{
    if (num==0)
    {
        temp_of_function_numberToString[0]='0';
        temp_of_function_numberToString[1]='\0';
        return 1;
    }
    int counter = 0;
    while( num > 0 )
    {
        temp_of_function_numberToString[counter]=(int)(num%10+48);
        counter++;
        num/=10;
    }
    temp_of_function_numberToString[counter]='\0';
    strrev(temp_of_function_numberToString);
    return counter;
}
void soundplay(SDL_Event ev)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    if(ev.type==SDL_MOUSEBUTTONDOWN && xCursor<=1828 && xCursor>=1720 &&yCursor<=138 && yCursor>=30)
    {
        sound=!sound;
    }
}
void showcursorandsound()
{
    if(sound)
    {
        SDL_Surface *img = SDL_LoadBMP("soundicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
        SDL_FreeSurface(img);
        SDL_DestroyTexture(texture_hitler);
    }
    else
    {
        SDL_Surface *img = SDL_LoadBMP("muteicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
        SDL_FreeSurface(img);
        SDL_DestroyTexture(texture_hitler);
    }
    SDL_GetMouseState(&xCursor,&yCursor);
    SDL_Surface *image_cursor= SDL_LoadBMP("cursor.bmp");
    if(!image_cursor)
        printf("ridi dar cursor %s",SDL_GetError());
    SDL_Rect cursor_place={.x=xCursor-50,.y=yCursor-40,.w=100,.h=80};
    SDL_Texture *texture_cursor= SDL_CreateTextureFromSurface(renderer,image_cursor);
    SDL_RenderCopy(renderer,texture_cursor,NULL,&cursor_place);
    if (!sound)
        Mix_PauseMusic();
    else
        Mix_ResumeMusic();
    SDL_FreeSurface(image_cursor);
    SDL_DestroyTexture(texture_cursor);
}
void show_text(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );

    SDL_FreeSurface( textSurface );

    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
    TTF_CloseFont(gFont);
}
void txtRGBA(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    roundedBoxRGBA(renderer,x-50,y-50,x+450,y+150,90,61,61,61,255);
    roundedBoxRGBA(renderer,x,y,x+400,y+100,90,78,78,78,255);
    x+=75;
    y+=20;
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );
    SDL_FreeSurface( textSurface );

    if (xCursor >= x && xCursor<=x+mWidth && yCursor>=y && yCursor<=y+mHeight)
    {
        SDL_Surface *image_hitler= SDL_LoadBMP("hitler.bmp");
        if(!image_hitler)
            printf("ridi dar hitler %s",SDL_GetError());
        SDL_Rect hitler_place={.x=900,.y=y-30,.w=320,.h=180};
        SDL_Texture *texture_hitler= SDL_CreateTextureFromSurface(renderer,image_hitler);
        SDL_RenderCopy(renderer,texture_hitler,NULL,&hitler_place);
        SDL_FreeSurface(image_hitler);
        SDL_DestroyTexture(texture_hitler);
    }
    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
    TTF_CloseFont(gFont);

}
void check_exit_game(SDL_Event ev)
{
    const SDL_MessageBoxButtonData buttons[] = {
            { /* .flags, .buttonid, .text */        0, 0, "YES" },
            { SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 1, "NO" }
    };
    const SDL_MessageBoxColorScheme colorScheme = {
            { /* .colors (.r, .g, .b) */
                    /* [SDL_MESSAGEBOX_COLOR_BACKGROUND] */
                    { 50,   50,   50 },
                    /* [SDL_MESSAGEBOX_COLOR_TEXT] */
                    {   255, 255,   255 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BORDER] */
                    { 0,   0,   0 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND] */
                    {   0, 0, 200 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED] */
                    { 255,   0, 0 }
            }
    };
    const SDL_MessageBoxData messageboxdata = {
            SDL_MESSAGEBOX_INFORMATION, /* .flags */
            NULL, /* .window */
            "EXIT", /* .title */
            "Are you sure you want to exit ?", /* .message */
            SDL_arraysize(buttons), /* .numbuttons */
            buttons, /* .buttons */
            &colorScheme /* .colorScheme */
    };
    int buttonid=-1;
    if (ev.type==SDL_QUIT)
    {
        SDL_ShowMessageBox(&messageboxdata, &buttonid);
        if(buttonid==0)
            game_is_running=false;
    }
    else
    if (ev.type==SDL_KEYUP && ev.key.keysym.sym==SDLK_ESCAPE)
    {
        SDL_ShowMessageBox(&messageboxdata, &buttonid);
        if(buttonid==0)
            game_is_running=false;
    }

}
bool is_ok_to_run_game()
{
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER |SDL_INIT_AUDIO) < 0)
    {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return false;
    }
    return true;
}
void render_blocks(int num_block,uint32_t arr[],struct block block[],SDL_Texture *block_khali,SDL_Texture *block_por)
{
    for(int i=0;i<num_block;i++)
    {
        if (block[i].index==-1)
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            SDL_RenderCopy(renderer,block_khali,NULL,&rect);
            if(number_to_string(block[i].number_soldier)==1)
                show_text(renderer,block[i].xpos-15,block[i].ypos+10,temp_of_function_numberToString,40,0,255,0,255);
            else if(number_to_string(block[i].number_soldier)==2)
                show_text(renderer,block[i].xpos-25,block[i].ypos+10,temp_of_function_numberToString,40,0,0,255,255);
            else if(number_to_string(block[i].number_soldier)==3)
                show_text(renderer,block[i].xpos-35,block[i].ypos+10,temp_of_function_numberToString,40,255,0,0,255);
        }
        else
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            filledCircleColor(renderer, block[i].xpos, block[i].ypos, 100, arr[block[i].index]);
            SDL_RenderCopy(renderer,block_por,NULL,&rect);
            if(number_to_string(block[i].number_soldier)==1)
                show_text(renderer,block[i].xpos-15,block[i].ypos+5,temp_of_function_numberToString,50,0,255,0,255);
            else if(number_to_string(block[i].number_soldier)==2)
                show_text(renderer,block[i].xpos-30,block[i].ypos+5,temp_of_function_numberToString,50,0,0,255,255);
            else if(number_to_string(block[i].number_soldier)==3)
                show_text(renderer,block[i].xpos-44,block[i].ypos+5,temp_of_function_numberToString,50,255,0,0,255);

        }
    }
}
void make_randomcolor(uint32_t arr[],int n)
{
    time_t t;
    int random_numbers[9];
    for(int i=0;i<9;i++)
        random_numbers[i]=-1;
    int count =0;
    srand((unsigned) time(&t));
    while(count <9)
    {
        int randNum =rand()%9;
        bool found =false;
        for (int i = 0; i < count; i++) {
            if(random_numbers[i] ==randNum) {
                found =true;
                break;
            }
        }
        if(!found) {
            random_numbers[count] =randNum;
            count++;
        }
    }
    for( int i = 0 ; i < n ; i++ )
    {
        arr[i+1]=clr[random_numbers[i]+1];
        //arr[i]=clr[i];
    }
    arr[0]=clr[0];
}
bool click_new_game(SDL_Event ev)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    if(ev.type==SDL_MOUSEBUTTONDOWN)
    {
        if(xCursor >= 1375 && xCursor <=1375+276 && yCursor>=270 && yCursor<=339 )
        {
            return true;
        }
    }
    return false;
}
void render_soldier(struct warstatus war[],int number_of_war,SDL_Texture *texttemp[],uint32_t arr_color[],struct block blocks[])
{
    SDL_Texture *temp;
    for(int i=0;i<number_of_war;i++)
    {
        struct soldier * current = war[i].head;
        while(current->next!=NULL)
        {
            if ( arr_color[current->index] == clr[0])
                temp = texttemp[0];
            else if ( arr_color[current->index]  == clr[1])
                temp=texttemp[1];
            else if (arr_color[current->index] == clr[2])
                temp=texttemp[2];
            else if (arr_color[current->index] == clr[3])
                temp=texttemp[3];
            else if (arr_color[current->index] == clr[4])
                temp=texttemp[4];
            else if (arr_color[current->index] == clr[5])
                temp=texttemp[5];
            else if (arr_color[current->index] == clr[6])
                temp=texttemp[6];
            else if (arr_color[current->index] == clr[7])
                temp=texttemp[7];
            else if (arr_color[current->index] == clr[8])
                temp=texttemp[8];
            else if (arr_color[current->index] == clr[9])
                temp=texttemp[9];

            SDL_Rect texture_soldier={.x=current->x-25,.y=current->y-25,.w=50,.h=50};
            SDL_RenderCopy(renderer,temp,NULL,&texture_soldier);
            // filledCircleColor(renderer,current->x,current->y,15,arr_color[blocks[current->num_beg_block].index]);
            current=current->next;
        }

    }
}
char inputs_string(SDL_Event ev)
{
    char ch;
    if(ev.type==SDL_KEYUP)
    {
        ch = (char)ev.key.keysym.sym;
        return ch;
    }
}
void generate_one_soldier_end_of_list(struct soldier * head,struct block* att,struct block def,int number_of_dest_block,int number_of_beg_block)
{
    static long long temp=0;
    struct soldier * current = head;
    while(current->next!=NULL)
    {
        current=current->next;
    }
    att->number_soldier-=1;
    current->next=(struct soldier*)malloc(sizeof(struct soldier));
    if(temp%3==0) {
        current->x = att->xpos-20;
        current->y = att->ypos-20;
    }
    if(temp%3==1)
    {
        current->x = att->xpos;
        current->y = att->ypos;
    }
    if(temp%3==2)
    {
        current->x = att->xpos+20;
        current->y = att->ypos+20;
    }
    double vatar=sqrt( (def.xpos-att->xpos)*(def.xpos-att->xpos) + (def.ypos-att->ypos)*(def.ypos-att->ypos));
    current->vx=Vsoldier*(def.xpos-att->xpos)/vatar;
    current->vy=Vsoldier*(def.ypos-att->ypos)/vatar;
    current->destx=def.xpos;
    current->desty=def.ypos;
    current->index=att->index;
    current->num_dest_block=number_of_dest_block;
    current->num_beg_block=number_of_beg_block;
    current->stop=false;
    current->fast_run=false;
    current->next->next=NULL;

    temp++;
}
bool is_same_soldier(struct soldier a,struct soldier b)
{
    if(a.x==b.x && a.y==b.y && a.vx==b.vx && a.vy==b.vy)
        return true;
    else
        return false;
}
int delete_soldier(struct soldier dest_for_delete,struct soldier ** head)
{
    struct  soldier *current = (*head);
    if (is_same_soldier(*current,dest_for_delete))
    {
        (*head) = (*head)->next;
        return 1;
    }
    while(current->next!=NULL)
    {
        if (is_same_soldier(*(current->next),dest_for_delete))
        {
            current->next = current->next->next;
            return 1;
        }
        current=current->next;
    }
    return 0;//in sarbaz vojood nadasht
}
void moving_soldiers(struct warstatus war[],struct block arr_block[])
{
    for(int i=0;i<NUM_WAR;i++)
    {
        struct soldier * current= war[i].head;
        while(current->next!=NULL)
        {
            if(current->stop == true)
            {
            }
            else if(current->fast_run == true)
            {
                current->x += 3*current->vx;
                current->y += 3*current->vy;
            }
            else
            {
                current->x += current->vx;
                current->y += current->vy;
            }

            if( current->x  - current->destx <80
                &&  -80 < current->x  - current->destx
                &&  current->y  - current->desty <80
                &&    -80 < current->y  - current->desty
                    )
            {
                if (arr_block[current->num_dest_block].index==arr_block[current->num_beg_block].index)
                {
                    arr_block[current->num_dest_block].number_soldier += 1;
                    arr_block[current->num_dest_block].number_soldier2 += 1;
                }
                else
                {
                    if (arr_block[current->num_dest_block].number_soldier == 0 )
                    {
                        arr_block[current->num_dest_block].index=arr_block[current->num_beg_block].index;
                        arr_block[current->num_dest_block].number_soldier = 1;
                        arr_block[current->num_dest_block].number_soldier2 = 1;
                        for(int j=0;j<NUM_WAR;j++)
                            if(war[j].att==current->num_dest_block)
                                war[j].num_soldier=0;
                    }
                    else
                    {
                        arr_block[current->num_dest_block].number_soldier -= 1;
                        arr_block[current->num_dest_block].number_soldier2 -= 1;
                    }
                }
                delete_soldier(*current,&war[i].head);
            }
            for(int j=i+1;j<100;j++)
            {
                struct soldier * cur2= war[j].head;
                while(cur2->next!=NULL)
                {
                    if (sqrt((current->x - cur2->x)*(current->x - cur2->x) + (current->y - cur2->y)*(current->y - cur2->y)) < 50)
                    {
                        if(arr_block[current->num_beg_block].index != arr_block[cur2->num_beg_block].index)
                        {
                            delete_soldier(*current, &war[i].head);
                            delete_soldier(*cur2, &war[j].head);
                        }
                    }
                    cur2=cur2->next;
                }
            }
            current=current->next;
        }
    }
}
void generate_all_wars_soldiers(struct warstatus war[],int number_of_wars,struct block arr_of_blocks[])
{
    for(int i=0;i<number_of_wars;i++)
    {
        if( arr_of_blocks[war[i].att].number_soldier == 0)
        {
            war[i].num_soldier=0;
        }
        if (war[i].counter < war[i].num_soldier)
        {
            generate_one_soldier_end_of_list(war[i].head,&arr_of_blocks[war[i].att],arr_of_blocks[war[i].def],war[i].def,war[i].att);
            war[i].counter+=1;
        }
    }
}
struct axis generate_random_potion(struct block arr_block[],int num_block)
{
    time_t t;
    srand((unsigned) time(&t));
    int a=rand() % num_block;
    int b=rand() % num_block;
    struct axis temp;
    int x= (arr_block[a].xpos+arr_block[b].xpos)/2;
    int y= (arr_block[a].ypos+arr_block[b].ypos)/2;
    temp.x=x;
    temp.y=y;
    return temp;
}
void render_potion(struct potion all[],SDL_Texture *arrdeactive[4],SDL_Texture *arractive[4])
{
    for(int i=0;i<NUM_POTOION;i++)
    {
        if(all[i].exist==true && all[i].runnig==false)
        {
            SDL_Rect temp={.x=all[i].x-60,.y=all[i].y-60,.h=120,.w=120};
            SDL_RenderCopy(renderer,arrdeactive[i%4],NULL,&temp);
        }
        if(all[i].exist==true && all[i].runnig==true)
        {
            SDL_Rect temp={.x=all[i].x-60,.y=all[i].y-60,.h=120,.w=120};
            SDL_RenderCopy(renderer,arractive[i%4],NULL,&temp);
        }
    }
}
void check_to_active_potion(struct potion all[],struct  warstatus war[])
{
    for(int i=0;i<NUM_POTOION;i++)
    {
        if(all[i].exist==true && all[i].runnig==false)
        {
            for (int j = 0; j < NUM_WAR; j++)
            {
                struct soldier *current = war[j].head;
                while (current->next != NULL)
                {
                    double R = sqrt((current->x - all[i].x) * (current->x - all[i].x) +
                                    (current->y - all[i].y) * (current->y - all[i].y));
                    if (R <= 85)
                    {
                        all[i].runnig = true;
                        all[i].index = current->index;
                        fps_potion[i]=0;
                        if(current->index==0)
                            your_potion=true;
                        else
                            ai_potion=true;
                        break;
                    }
                    current = current->next;
                }
            }
        }
    }
}
void run_potion(struct potion potions[],struct warstatus wars[],struct block arr_block[],int numBlock)
{
    for(int i=0;i<NUM_POTOION;i++)
    {
        if(potions[i].runnig == true && potions[i].exist==true)
        {
            //   printf("%d is running\n",i);
            switch (i%4)
            {
                case 0:
                    for (int j = 0; j < NUM_WAR; j++)
                    {
                        struct soldier *current = wars[j].head;
                        while (current->next != NULL)
                        {
                            if(current->index==potions[i].index)
                                current->fast_run=true;
                            current=current->next;
                        }
                    }
                    break;
                case 1:
                    for (int j = 0; j < NUM_WAR; j++)
                    {
                        struct soldier *current = wars[j].head;
                        while (current->next != NULL)
                        {
                            if(current->index != potions[i].index)
                                current->stop=true;
                            current=current->next;
                        }
                    }
                    break;
                case 2:
                    for (int j = 0; j < numBlock; j++)
                    {
                        if(arr_block[j].index == potions[i].index)
                            arr_block[j].nolimit=true;
                    }
                    break;
                case 3:
                    for (int j = 0; j < numBlock; j++)
                    {
                        if(arr_block[j].index == potions[i].index)
                            arr_block[j].fastblock=true;
                    }
                    break;

            }
        }
    }
}
void deactive_potion(struct potion potions,int i,struct warstatus wars[],struct block arr_block[],int numBlock)
{
    if(potions.runnig==true && potions.exist==true)
    {
        switch (i % 4) {
            case 0:
                for (int j = 0; j < NUM_WAR; j++) {
                    struct soldier *current = wars[j].head;
                    while (current->next != NULL) {
                        if (current->index == potions.index)
                            current->fast_run = false;
                        current = current->next;
                    }
                }
                break;
            case 1:
                for (int j = 0; j < NUM_WAR; j++) {
                    struct soldier *current = wars[j].head;
                    while (current->next != NULL) {
                        if (current->index != potions.index)
                            current->stop = false;
                        current = current->next;
                    }
                }
                break;
            case 2:
                for (int j = 0; j < numBlock; j++) {
                    if (arr_block[j].index == potions.index)
                        arr_block[j].nolimit = false;
                }
                break;
            case 3:
                for (int j = 0; j < numBlock; j++) {
                    if (arr_block[j].index == potions.index)
                        arr_block[j].fastblock = false;
                }
                break;
        }
    }
}
struct axis AI1(struct block arr[],int numblock)
{
    struct axis temp;
    time_t t;
    double R;
    double Rmin=5000;
    bool found=false;
    int random_numbers[numblock];{
        for (int i = 0; i < numblock; i++)
            random_numbers[i] = -1;
        int count = 0;
        srand((unsigned) time(&t));
        while (count < numblock) {
            int randNum = rand() % numblock;
            bool found = false;
            for (int i = 0; i < count; i++) {
                if (random_numbers[i] == randNum) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                random_numbers[count] = randNum;
                count++;
            }
        }
    }
    for(int i = 0 ;i<numblock;i++)
    {
        if( arr[random_numbers[i]].index != 0 && arr[random_numbers[i]].index !=-1)
        {
            for (int j = 0; j < numblock; j++)
            {
                if (arr[random_numbers[i]].number_soldier2 > arr[random_numbers[j]].number_soldier2 + 1 &&
                    arr[random_numbers[i]].index!=arr[random_numbers[j]].index)
                {
                    printf("n %d %d\n",random_numbers[i],random_numbers[j]);
                    R=sqrt(( (arr[random_numbers[i]].xpos-arr[random_numbers[j]].xpos)
                             *(arr[random_numbers[i]].xpos-arr[random_numbers[j]].xpos)) +
                           ((arr[random_numbers[i]].ypos-arr[random_numbers[j]].ypos) *
                            (arr[random_numbers[i]].ypos-arr[random_numbers[j]].ypos)));
                    if (R < Rmin)
                    {
                        temp.x=random_numbers[i];
                        temp.y=random_numbers[j];
                        Rmin=R;
                        found=true;
                    }
                }
            }
            if(found)
                return temp;
        }
    }
    struct axis p;
    p.x=-1;
    p.y=-1;
    return p;
}
struct axis AI2(struct block arr[],int numblock)
{
    struct axis temp;
    time_t t;
    int soldier;
    double smin=1000;
    bool found=false;
    int random_numbers[numblock];{
        for (int i = 0; i < numblock; i++)
            random_numbers[i] = -1;
        int count = 0;
        srand((unsigned) time(&t));
        while (count < numblock) {
            int randNum = rand() % numblock;
            bool found = false;
            for (int i = 0; i < count; i++) {
                if (random_numbers[i] == randNum) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                random_numbers[count] = randNum;
                count++;
            }
        }
    }
    for(int i = 0 ;i<numblock;i++)
    {
        if( arr[random_numbers[i]].index != 0 && arr[random_numbers[i]].index !=-1)
        {
            for (int j = 0; j < numblock; j++)
            {
                if (arr[random_numbers[i]].number_soldier2 > arr[random_numbers[j]].number_soldier2 + 1)
                {
                    soldier=arr[random_numbers[j]].number_soldier2;
                    if (soldier < smin)
                    {
                        temp.x=random_numbers[i];
                        temp.y=random_numbers[j];
                        smin=soldier;
                        found=true;
                    }
                }
            }
            if(found)
                return temp;
        }
    }
    struct axis p;
    p.x=-1;
    p.y=-1;
    return p;
}
struct axis AI3(struct block arr[],int numblock)
{
    struct axis temp;
    time_t t;
    int soldier;
    double smin=1000;
    bool found=false;
    int random_numbers[numblock];{
        for (int i = 0; i < numblock; i++)
            random_numbers[i] = -1;
        int count = 0;
        srand((unsigned) time(&t));
        while (count < numblock) {
            int randNum = rand() % numblock;
            bool found = false;
            for (int i = 0; i < count; i++) {
                if (random_numbers[i] == randNum) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                random_numbers[count] = randNum;
                count++;
            }
        }
    }
    for(int i = 0 ;i<numblock;i++)
    {
        if( arr[random_numbers[i]].index != 0 && arr[random_numbers[i]].index !=-1)
        {
            for (int j = 0; j < numblock; j++)
            {
                if (arr[random_numbers[i]].number_soldier2 > arr[random_numbers[j]].number_soldier2 + 1
                    && arr[random_numbers[j]].index==0 )
                {
                    soldier=arr[random_numbers[j]].number_soldier2;
                    if (soldier < smin)
                    {
                        temp.x=random_numbers[i];
                        temp.y=random_numbers[j];
                        smin=soldier;
                        found=true;
                    }
                }
            }
            if(found)
                return temp;
        }
    }
    struct axis p;
    p.x=-1;
    p.y=-1;
    return p;
}
bool win(struct block arr[],int numblock)
{
    bool youwin=true;
    for(int i=0;i<numblock;i++)
    {
        if(arr[i].index!=0 && arr[i].index!=-1)
            youwin=false;
    }
    return youwin;
}
bool lose(struct block arr[],int numblock)
{
    bool youlose=true;
    for(int i=0;i<numblock;i++)
    {
        if(arr[i].index == 0 )
            youlose=false;
    }
    return youlose;
}