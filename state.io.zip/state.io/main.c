#include "functions.h"
char name[200]=" ";
void map()
{
    struct potion pot[NUM_POTOION];
    for(int i=0;i<NUM_POTOION;i++)
    {
        pot[i].exist=false;
        pot[i].runnig=false;
        pot[i].index=-1;
    }

    declareclr();
    struct warstatus wars[NUM_WAR]; //in 10000 kheili jaha 100 e dorostesh kon
    for(int i=0;i<NUM_WAR;i++)
       wars[i].head=(struct soldier*)malloc(sizeof(struct soldier));
    for(int i=0;i<NUM_WAR;i++)
        wars[i].head->next=NULL;
    int number_of_attack=0;

    int blockclicked1=-1;
    int blockclicked2=-1;
    bool is_in_war=false;

    for (int j=0;j<5;j++)
    {
        for (int i = 0; i < 9; i++)
        {
            all_block[j * 9 + i].xpos = 160 + i * 200;
            all_block[j * 9 + i].ypos = 110 + j * 200;
            all_block[j * 9 + i].index=-1;
            all_block[j * 9 + i].number_soldier=15;
            all_block[j * 9 + i].number_soldier2=15;
            all_block[j * 9 + i].nolimit=false;
            all_block[j * 9 + i].fastblock=false;
        }
    }
    int number_of_block,number_of_player;
    scanf("%d %d",&number_of_block,&number_of_player);
    uint32_t arr_of_colors[number_of_player];
    struct block arr_of_block[number_of_block];
    make_randomcolor(arr_of_colors,number_of_player);
    {
        time_t t;
        int random_numbers[number_of_block];
        for(int i=0;i<number_of_block;i++)
            random_numbers[i]=-1;
        int count =0;
        srand((unsigned) time(&t));
        while(count <number_of_block) {
            int randNum =rand()%45;
            if (randNum==8)
                continue;
            bool found =false;
            for (int i = 0; i < count; i++) {
                if(random_numbers[i] ==randNum) {
                    found =true;
                    break;
                }
            }
            if(!found) {
                random_numbers[count] =randNum;
                count++;
            }
        }

        for(int i=0;i<number_of_block;i++) {
            arr_of_block[i] = all_block[random_numbers[i]];
            if (i < number_of_player)
                arr_of_block[i].index=i;
        }
//            printf("%d ",random_numbers[i]);


    }  //inja miad arr_of_block ro random tarif mikone az all block
    ///berim hala karaye rendering
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    music = Mix_LoadMUS("music_war2.mp3");
    Mix_Music *warningmusic=Mix_LoadMUS("potionmusic.mp3");

        if (!is_ok_to_run_game())
        return ;
    window = SDL_CreateWindow("game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("map_war2.bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);

    SDL_Surface* warningimg = SDL_LoadBMP("warning  .bmp");
    if (!warningimg)
        printf("ridi %s", SDL_GetError());
    SDL_Texture  *warningtxt = SDL_CreateTextureFromSurface(renderer, warningimg);
  //  SDL_SetTextureAlphaMod(warningtxt,150);


    SDL_Surface *image_block_por = SDL_LoadBMP("block_por.bmp");
    if (!image_block_por)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_block_por = SDL_CreateTextureFromSurface(renderer, image_block_por);

    SDL_Surface *image_block_khali = SDL_LoadBMP("block_khali.bmp");
    if (!image_block_khali)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_block_khali = SDL_CreateTextureFromSurface(renderer, image_block_khali);

    SDL_Surface *image_soldier[10];
    image_soldier[0] = SDL_LoadBMP("s0.bmp");
    image_soldier[1] = SDL_LoadBMP("s1.bmp");
    image_soldier[2] = SDL_LoadBMP("s2.bmp");
    image_soldier[3] = SDL_LoadBMP("s3.bmp");
    image_soldier[4] = SDL_LoadBMP("s4.bmp");
    image_soldier[5] = SDL_LoadBMP("s5.bmp");
    image_soldier[6] = SDL_LoadBMP("s6.bmp");
    image_soldier[7] = SDL_LoadBMP("s7.bmp");
    image_soldier[8] = SDL_LoadBMP("s8.bmp");
    image_soldier[9] = SDL_LoadBMP("s9.bmp");

    SDL_Texture *texture_soldier[10] ;
    texture_soldier[0]= SDL_CreateTextureFromSurface(renderer, image_soldier[0]);
    texture_soldier[1]= SDL_CreateTextureFromSurface(renderer, image_soldier[1]);
    texture_soldier[2]= SDL_CreateTextureFromSurface(renderer, image_soldier[2]);
    texture_soldier[3]= SDL_CreateTextureFromSurface(renderer, image_soldier[3]);
    texture_soldier[4]= SDL_CreateTextureFromSurface(renderer, image_soldier[4]);
    texture_soldier[5]= SDL_CreateTextureFromSurface(renderer, image_soldier[5]);
    texture_soldier[6]= SDL_CreateTextureFromSurface(renderer, image_soldier[6]);
    texture_soldier[7]= SDL_CreateTextureFromSurface(renderer, image_soldier[7]);
    texture_soldier[8]= SDL_CreateTextureFromSurface(renderer, image_soldier[8]);
    texture_soldier[9]= SDL_CreateTextureFromSurface(renderer, image_soldier[9]);

    SDL_Surface *image_potionD[4];
    image_potionD[0]= SDL_LoadBMP("p0.bmp");
    image_potionD[1]= SDL_LoadBMP("p1.bmp");
    image_potionD[2]= SDL_LoadBMP("p2.bmp");
    image_potionD[3]= SDL_LoadBMP("p3.bmp");
    SDL_Texture *texture_potionD[4];
    texture_potionD[0]= SDL_CreateTextureFromSurface(renderer,image_potionD[0]);
    texture_potionD[1]= SDL_CreateTextureFromSurface(renderer,image_potionD[1]);
    texture_potionD[2]= SDL_CreateTextureFromSurface(renderer,image_potionD[2]);
    texture_potionD[3]= SDL_CreateTextureFromSurface(renderer,image_potionD[3]);

    SDL_Surface *image_potionA[4];
    image_potionA[0]= SDL_LoadBMP("Ap0.bmp");
    image_potionA[1]= SDL_LoadBMP("Ap1.bmp");
    image_potionA[2]= SDL_LoadBMP("Ap2.bmp");
    image_potionA[3]= SDL_LoadBMP("Ap3.bmp");
    SDL_Texture *texture_potionA[4];
    texture_potionA[0]= SDL_CreateTextureFromSurface(renderer,image_potionA[0]);
    texture_potionA[1]= SDL_CreateTextureFromSurface(renderer,image_potionA[1]);
    texture_potionA[2]= SDL_CreateTextureFromSurface(renderer,image_potionA[2]);
    texture_potionA[3]= SDL_CreateTextureFromSurface(renderer,image_potionA[3]);
//    SDL_SetTextureAlphaMod(texture_potionA[0],220);
//    SDL_SetTextureAlphaMod(texture_potionA[1],220);
//    SDL_SetTextureAlphaMod(texture_potionA[2],220);
//    SDL_SetTextureAlphaMod(texture_potionA[3],220);
//
//    SDL_SetTextureAlphaMod(texture_potionD[0],240);
//    SDL_SetTextureAlphaMod(texture_potionD[1],240);
//    SDL_SetTextureAlphaMod(texture_potionD[2],240);
//    SDL_SetTextureAlphaMod(texture_potionD[3],240);

    Mix_PlayMusic(music,-1);
    long long counterFPS=0;
    long long countai=0;
    while (game_is_running)
    {
        if (counterFPS == 9223372036854775807)
            counterFPS = 0;
        if (countai == 9223372036854775807)
            countai = 0;
        counterFPS++;
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        SDL_ShowCursor(SDL_DISABLE);
        render_blocks(number_of_block, arr_of_colors, arr_of_block, texture_block_khali, texture_block_por);
        while (SDL_PollEvent(&event)) {
            blockclicked2 = which_block_clicked(arr_of_block, number_of_block, event);
            soundplay(event);
            check_exit_game(event);
        }

        moving_soldiers(wars, arr_of_block);
        check_to_active_potion(pot, wars);

        if (ai_potion == true) {
            SDL_RenderCopy(renderer, warningtxt, NULL, &texture_rect);
            SDL_RenderPresent(renderer);
            SDL_Delay(500);
        }
        ai_potion = false;
        if (your_potion == true) {
            Mix_PlayMusic(warningmusic, 1);
        }
        your_potion = false;
        if (!Mix_PlayingMusic())
            Mix_PlayMusic(music, -1);
        run_potion(pot, wars, arr_of_block, number_of_block);

        render_potion(pot, texture_potionD, texture_potionA);
        render_soldier(wars, number_of_attack, texture_soldier, arr_of_colors, arr_of_block);
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
        if (counterFPS % 60 == 0)  //har 1 sanie ba ehtemal 10%
        {
            time_t t;
            srand((unsigned) time(&t));
            int pp=rand()%2;
            if (pp!=0)   //generate potion
            {
                bool tekrari = false;
                struct axis temp = generate_random_potion(arr_of_block, number_of_block);
                for (int i = 0; i < NUM_POTOION; i++)
                    if (temp.x == pot[i].x && temp.y == pot[i].y && pot[i].exist == true)
                        tekrari = true;
                int tmp = rand() % NUM_POTOION;
                if (!pot[tmp].exist && !tekrari) {
                    fps_potion[tmp] = 0;
                    pot[tmp].x = temp.x;
                    pot[tmp].y = temp.y;
                    pot[tmp].exist = true;
                    pot[tmp].runnig = false;
                }
            }
        }
        if (counterFPS % 60 == 0) {
            for (int i = 0; i < number_of_block; i++) {
                if (arr_of_block[i].index != -1) {
                    if (arr_of_block[i].nolimit == true && arr_of_block[i].fastblock == true) {
                        arr_of_block[i].number_soldier += 2;
                        arr_of_block[i].number_soldier2 += 2;
                    } else if (arr_of_block[i].nolimit == true && arr_of_block[i].fastblock == false) {
                        arr_of_block[i].number_soldier++;
                        arr_of_block[i].number_soldier2++;
                    } else if (arr_of_block[i].nolimit == false && arr_of_block[i].fastblock == true) {
                        if (arr_of_block[i].number_soldier < max_sarbaz) {
                            arr_of_block[i].number_soldier += 2;
                            arr_of_block[i].number_soldier2 += 2;
                        }

                    } else if (arr_of_block[i].nolimit == false && arr_of_block[i].fastblock == false) {
                        if (arr_of_block[i].number_soldier < max_sarbaz) {
                            arr_of_block[i].number_soldier++;
                            arr_of_block[i].number_soldier2++;
                        }
                    }
                }
            }
        }
        if (counterFPS % 10 == 0) {
            generate_all_wars_soldiers(wars, number_of_attack, arr_of_block);
        }
        if (blockclicked2 != -1)
        {
            if (blockclicked1 == -1)
            {
                if (arr_of_block[blockclicked2].index != 0)
                    blockclicked2 = -1;
                else {
                    blockclicked1 = blockclicked2;
                    blockclicked2 = -1;
                }
            } else  //bayad jang start beshe
            {
                if (blockclicked2 != blockclicked1) {
                    wars[number_of_attack].def = blockclicked2;
                    wars[number_of_attack].att = blockclicked1;
                    wars[number_of_attack].num_soldier = arr_of_block[blockclicked1].number_soldier2;
                    arr_of_block[blockclicked1].number_soldier2 = 0;
                    wars[number_of_attack].counter = 0;
                    number_of_attack++;
                }
                blockclicked2 = -1;
                blockclicked1 = -1;
            }
        }
        for (int i = 0; i < NUM_POTOION; i++) {
            if (pot[i].exist == true)
                fps_potion[i]++;
            if (fps_potion[i] > 150 && pot[i].runnig == false) {
                pot[i].exist = false;
                pot[i].runnig = false;
            }
            if (fps_potion[i] > 300 && pot[i].runnig == true) {
                if (pot[i].index == 0)
                    your_potion = false;
                else
                    ai_potion = false;
                deactive_potion(pot[i], i, wars, arr_of_block, number_of_block);
                pot[i].exist = false;
                pot[i].runnig = false;
            }
        }
        struct axis AIatack ;
        if (counterFPS % 100==0 )
        {
            countai++;
            if(countai%3==0)
               AIatack = AI1(arr_of_block, number_of_block);
            else if(countai %3==1)
                AIatack = AI2(arr_of_block, number_of_block);
            else if(countai %3==2)
                AIatack = AI3(arr_of_block, number_of_block);
            if (AIatack.x != -1 && AIatack.y != -1)
            {
                printf("%d %d\n", AIatack.x, AIatack.y);
                wars[number_of_attack].def = AIatack.y;
                wars[number_of_attack].att = AIatack.x;
                wars[number_of_attack].num_soldier = arr_of_block[AIatack.x].number_soldier2;
                arr_of_block[AIatack.x].number_soldier2 = 0;
                wars[number_of_attack].counter = 0;
                number_of_attack++;
            }
        }
        if (win(arr_of_block,number_of_block))
        {
            printf("win");
            break;
        }
        if(lose(arr_of_block,number_of_block))
        {
            printf("lose");
            break;
        }
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
     Mix_FreeMusic(warningmusic);
    Mix_FreeMusic(music);
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    music=NULL;
    Mix_Quit();
    SDL_Quit();
    return ;
}
void menu() {
    strcat(name_used_in_menu,name);
    TTF_Init();
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    music= Mix_LoadMUS("music.mp3");
    if (!is_ok_to_run_game())
        return ;
    window = SDL_CreateWindow("menu", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("menu .bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);
    Mix_PlayMusic(music,-1);
    while (game_is_running) {
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        show_text(renderer,0,0,name_used_in_menu,60,255,0,0,255);
        txtRGBA(renderer, 1300, 200 + 50, "NEW GAME", 50, 160, 13, 10, 255);
        txtRGBA(renderer, 1300, 440 + 50, "CONTINUE", 50, 160, 13, 10, 255);
        txtRGBA(renderer, 1300, 680 + 50, " RANKING", 50, 160, 13, 10, 255);
        while(SDL_PollEvent(&event))
        {
            if(click_new_game(event))
            {
                SDL_DestroyRenderer(renderer);
                SDL_DestroyWindow(window);
                SDL_DestroyTexture(texture);
                SDL_FreeSurface(image);
                Mix_FreeMusic(music);
                window = NULL;
                renderer = NULL;
                texture=NULL;
                image=NULL;
                music=NULL;
                map();
                return;
            }
            soundplay(event);
            check_exit_game(event);
        }
        SDL_ShowCursor(SDL_DISABLE);
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    music=NULL;
    Mix_Quit();
    SDL_Quit();
}
void first_page()
{
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    music= Mix_LoadMUS("music_first.mp3");
    if (!is_ok_to_run_game())
        return ;
    window = SDL_CreateWindow("HELLO", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("bf4.bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);

    SDL_Surface *imagegame = SDL_LoadBMP("gamename.bmp");
    if (!imagegame)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texturegame = SDL_CreateTextureFromSurface(renderer, imagegame);
    int tool=imagegame->w / 4;
    int arz=imagegame->h  / 4;
    int temp99=0,temp98=0;
    int centerx=960;
    int centery=650;
    Mix_PlayMusic(music,-1);
    SDL_Rect temp_rect;
    while(tool < imagegame->w /2 && game_is_running)
    {
        SDL_ShowCursor(SDL_DISABLE);
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        show_text(renderer,30,30,"LOADING PLEASE WAIT ..",60,0,0,0,255);
        temp_rect.x=centerx-tool/2;
        temp_rect.y=centery-arz/2;
        temp_rect.w=tool;
        temp_rect.h=arz;
        tool+=1;
        arz+=1;
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        while(SDL_PollEvent(&event))
        {
            soundplay(event);
            check_exit_game(event);
        }
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_RenderClear(renderer);
    }   //loading aval
    while(game_is_running && temp99<255)
    {
        SDL_ShowCursor(SDL_DISABLE);
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        show_text(renderer, 30, 30, "PLEASE ENTER YOUR NAME THEN PRESS ENTER :", 40, 40, 2, 90, temp99);
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        SDL_ShowCursor(SDL_DISABLE);

        while(SDL_PollEvent(&event))
        {
            soundplay(event);
            check_exit_game(event);
        }

        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_RenderClear(renderer);
        temp99+=5;
    }  //neveshtan enter name
    while(game_is_running)
    {
        SDL_ShowCursor(SDL_DISABLE);
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        show_text(renderer, 30, 30, "PLEASE ENTER YOUR NAME THEN PRESS ENTER :", 40, 40, 2, 90, 255);
        show_text(renderer,50,150,name,40,0,0,0,255);
        while(SDL_PollEvent(&event))
        {
            soundplay(event);
            check_exit_game(event);
            char ch=inputs_string(event);
            if(('a'<=ch && ch <= 'z') || ch==' ')
                strncat(name,&ch,1);
            if(ch==SDLK_BACKSPACE && strlen(name)>1)
                name[strlen(name)-1]='\0';
            if(ch==SDLK_RETURN)
            {
                printf("\n%s",name);
                SDL_DestroyRenderer(renderer);
                SDL_DestroyWindow(window);
                SDL_DestroyTexture(texture);
                SDL_FreeSurface(image);
                Mix_FreeMusic(music);
                window = NULL;
                renderer = NULL;
                texture=NULL;
                image=NULL;
                music=NULL;
                menu();
                return;
            }
            event.key.keysym.sym = NULL;
            event.type = NULL;
        }
        showcursorandsound();
        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    Mix_Quit();
    SDL_Quit();
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    music=NULL;
}
void write_name_to_file()
{
    FILE *fptr;
    if ( (fptr = fopen("names.txt","w+")) == NULL)
    {
        printf("Error! opening file");
        return ;
    }
    char tenpname[200];
    int win=0;
    int lose=0;
    while(2 == fscanf(fptr,"%s %d %d",tenpname,&win,&lose))
    {
        if(!strcmp(tenpname,name))
        {
            fclose(fptr);
            return ;
        }
    }
    fprintf(fptr,"%s %d %d",name,0,0);
    fclose(fptr);
    return ;
}
void write_win_to_file()
{
    FILE *fptr;
    if ( (fptr = fopen("names.txt","w+")) == NULL)
    {
        printf("Error! opening file");
        return ;
    }
    char tenpname[200];
    int win=0;
    int lose=0;
    while(2 == fscanf(fptr,"%s %d %d",tenpname,&win,&lose))
    {
        if(!strcmp(tenpname,name))
        {

        }
    }
    fprintf(fptr,"%s %d %d",name,0,0);
    fclose(fptr);
    return ;
}
void write_lose_to_file()
{
    FILE *fptr;
    if ( (fptr = fopen("names.txt","w+")) == NULL)
    {
        printf("Error! opening file");
        return ;
    }
    char tenpname[200];
    int win=0;
    int lose=0;
    while(2 == fscanf(fptr,"%s %d %d",tenpname,&win,&lose))
    {
        if(!strcmp(tenpname,name))
        {
            fclose(fptr);
            return ;
        }
    }
    fprintf(fptr,"%s %d %d",name,0,0);
    fclose(fptr);
    return ;
}
int main()
{
  // first_page();
  // write_name_to_file();
   //menu();
   //map();
   return 0;
}