#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

struct block
{
    int xpos;
    int ypos;
    int index;   //-1 yani khali baghie raghama motealegh be rangesh
    int number_soldier;
};
struct block all_block[45];

int xCursor=0,yCursor=0;
SDL_Window *window=NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *texture=NULL;
SDL_Rect texture_rect={.x=0,.y=0,.w=1920,.h=1080};
SDL_Surface *image=NULL;
char name[200]="payam";
const int FPS = 60;
const int SCREEN_WIDTH = 1920;
const int SCREEN_HEIGHT = 1080;
bool game_is_running=true;
bool sound=true;
void soundplay()
{
    SDL_GetMouseState(&xCursor,&yCursor);
    SDL_Event ev;
    if(SDL_PollEvent(&ev))
    {
        if(ev.type==SDL_MOUSEBUTTONDOWN && xCursor<=1828 && xCursor>=1720 &&yCursor<=138 && yCursor>=30)
        {
            sound=!sound;
        }
    }
    if(sound)
    {
        SDL_Surface *img = SDL_LoadBMP("soundicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
    }
    else
    {
        SDL_Surface *img = SDL_LoadBMP("muteicon.bmp");
        if (!img)
            printf("ridi dar hitler %s", SDL_GetError());
        SDL_Rect place = {.x=1720, .y=30, .w=108, .h=108};
        SDL_Texture *texture_hitler = SDL_CreateTextureFromSurface(renderer, img);
        SDL_RenderCopy(renderer, texture_hitler, NULL, &place);
    }
}
void showcursor()
{
    SDL_GetMouseState(&xCursor,&yCursor);
    SDL_Surface *image_cursor= SDL_LoadBMP("cursor.bmp");
    if(!image_cursor)
        printf("ridi dar cursor %s",SDL_GetError());
    SDL_Rect cursor_place={.x=xCursor-50,.y=yCursor-40,.w=100,.h=80};
    SDL_Texture *texture_cursor= SDL_CreateTextureFromSurface(renderer,image_cursor);
    SDL_RenderCopy(renderer,texture_cursor,NULL,&cursor_place);
}
void show_text(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );
    SDL_FreeSurface( textSurface );

    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    SDL_DestroyTexture( mTexture );
}
void txtRGBA(SDL_Renderer *renderer,int x,int y,const char * text,int font_size,int R,int G,int B, int A)
{
    SDL_GetMouseState(&xCursor,&yCursor);
    roundedBoxRGBA(renderer,x-50,y-50,x+450,y+150,90,61,61,61,255);
    roundedBoxRGBA(renderer,x,y,x+400,y+100,90,78,78,78,255);
    x+=75;
    y+=20;
    TTF_Init();
    SDL_Color text_color = { R, G, B, A};
    const char * font_address_01="font.ttf";
    const char * Font =NULL;
    Font = font_address_01;
    int mWidth = 0;
    int mHeight = 0;
    SDL_Rect* clip = NULL;
    TTF_Font *gFont = NULL;
    double angle = 0.0;
    SDL_Point* center = NULL;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Texture* mTexture = NULL;
    gFont = TTF_OpenFont(Font, font_size );

    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont,text, text_color );

    mWidth = textSurface->w;
    mHeight = textSurface->h;
    mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );
    SDL_FreeSurface( textSurface );

    if (xCursor >= x && xCursor<=x+mWidth && yCursor>=y && yCursor<=y+mHeight)
    {
        SDL_Surface *image_hitler= SDL_LoadBMP("hitler.bmp");
        if(!image_hitler)
            printf("ridi dar hitler %s",SDL_GetError());
        SDL_Rect hitler_place={.x=900,.y=y-30,.w=320,.h=180};
        SDL_Texture *texture_hitler= SDL_CreateTextureFromSurface(renderer,image_hitler);
        SDL_RenderCopy(renderer,texture_hitler,NULL,&hitler_place);
    }
    SDL_Rect renderQuad = { x, y, mWidth, mHeight };
    SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );

    SDL_DestroyTexture( mTexture );

}
void check_exit_game()
{
    const SDL_MessageBoxButtonData buttons[] = {
            { /* .flags, .buttonid, .text */        0, 0, "YES" },
            { SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 1, "NO" }
    };
    const SDL_MessageBoxColorScheme colorScheme = {
            { /* .colors (.r, .g, .b) */
                    /* [SDL_MESSAGEBOX_COLOR_BACKGROUND] */
                    { 50,   50,   50 },
                    /* [SDL_MESSAGEBOX_COLOR_TEXT] */
                    {   255, 255,   255 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BORDER] */
                    { 0,   0,   0 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND] */
                    {   0, 0, 200 },
                    /* [SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED] */
                    { 255,   0, 0 }
            }
    };
    const SDL_MessageBoxData messageboxdata = {
            SDL_MESSAGEBOX_INFORMATION, /* .flags */
            NULL, /* .window */
            "EXIT", /* .title */
            "Are you sure you want to exit ?", /* .message */
            SDL_arraysize(buttons), /* .numbuttons */
            buttons, /* .buttons */
            &colorScheme /* .colorScheme */
    };
    int buttonid=-1;
    SDL_Event event;
    if (SDL_PollEvent(&event))
        if (event.type==SDL_QUIT)
        {
                SDL_ShowMessageBox(&messageboxdata, &buttonid);
                if(buttonid==0)
                    game_is_running=false;
        }

        else
            if (event.type==SDL_KEYUP && event.key.keysym.sym==SDLK_ESCAPE)
            {
                    SDL_ShowMessageBox(&messageboxdata, &buttonid);
                    if(buttonid==0)
                        game_is_running=false;
            }

}
uint32_t color(int r,int g, int b, int a){return    ( (a << 24) + (b<< 16) + (g << 8) + r) ;}
bool is_ok_to_run_game()
{
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER |SDL_INIT_AUDIO) < 0)
    {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return false;
    }
    return true;
}
void render_blocks(int num_block,uint32_t arr[],struct block block[],SDL_Texture *block_khali,SDL_Texture *block_por)
{
    for(int i=0;i<num_block;i++)
    {
        if (block[i].index==-1)
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            SDL_RenderCopy(renderer,block_khali,NULL,&rect);
        }
        else
        {
            SDL_Rect rect={.x=block[i].xpos-100, .y=block[i].ypos-100,.w=200,.h=200};
            filledCircleColor(renderer, block[i].xpos, block[i].ypos, 100, arr[block[i].index]);
            SDL_RenderCopy(renderer,block_por,NULL,&rect);
           // filledCircleColor(renderer, block[i].xpos, block[i].ypos, 90, color(150, 150, 150, 255));
        }
    }
}
void make_randomcolor(uint32_t arr[],int n)
{
        time_t t;
        srand((unsigned) time(&t));
        for( int i = 0 ; i < n ; i++ )
        {
            int r,g,b;
            r=rand() % 256;
            g=rand() % 256;
            b=rand() % 256;
            arr[i]= color(r,g,b,255);
        }
}
int menu() {
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    Mix_Music *music= Mix_LoadMUS("music.mp3");
    if (!is_ok_to_run_game())
        return -1;
    window = SDL_CreateWindow("menu", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("menu .bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);
    Mix_PlayMusic(music,-1);
    while (game_is_running) {
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        txtRGBA(renderer, 1300, 200 + 50, "NEW GAME", 50, 160, 13, 10, 255);
        txtRGBA(renderer, 1300, 440 + 50, "CONTINUE", 50, 160, 13, 10, 255);
        txtRGBA(renderer, 1300, 680 + 50, " RANKING", 50, 160, 13, 10, 255);
        soundplay();
        if(!sound)
            Mix_PauseMusic();
        else
            Mix_ResumeMusic();
        SDL_ShowCursor(SDL_DISABLE);
        showcursor();
        SDL_RenderPresent(renderer);
        check_exit_game();
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }

    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    Mix_Quit();
    SDL_Quit();
}
int map()
{

    for (int j=0;j<5;j++)
    {
        for (int i = 0; i < 9; i++)
        {
            all_block[j * 9 + i].xpos = 160 + i * 200;
            all_block[j * 9 + i].ypos = 110 + j * 200;
            all_block[j * 9 + i].index=-1;
            all_block[j * 9 + i].number_soldier=0;
        }
    }
    int number_of_block,number_of_player;
    scanf("%d %d",&number_of_block,&number_of_player);
    uint32_t arr_of_colors[number_of_player];
    struct block arr_of_block[number_of_block];

    make_randomcolor(arr_of_colors,number_of_player);

    {
            time_t t;
            int random_numbers[number_of_block];
            for(int i=0;i<number_of_block;i++)
                random_numbers[i]=-1;
            int count =0;
            srand((unsigned) time(&t));
            while(count <number_of_block) {
                int randNum =rand()%45;
                if (randNum==8)
                    continue;
                bool found =false;
                for (int i = 0; i < count; i++) {
                    if(random_numbers[i] ==randNum) {
                        found =true;
                        break;
                    }
                }
                if(!found) {
                    random_numbers[count] =randNum;
                    count++;
                }
            }

       for(int i=0;i<number_of_block;i++) {
           arr_of_block[i] = all_block[random_numbers[i]];
           if (i < number_of_player)
               arr_of_block[i].index=i;
       }
//            printf("%d ",random_numbers[i]);


    }  //inja miad arr_of_block ro random tarif mikone az all block


    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    Mix_Music *music= Mix_LoadMUS("music_war2.mp3");
    if (!is_ok_to_run_game())
        return -1;
    window = SDL_CreateWindow("game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("map_war2.bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);

    SDL_Surface *image_block_por = SDL_LoadBMP("block_por.bmp");
    if (!image_block_por)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_block_por = SDL_CreateTextureFromSurface(renderer, image_block_por);

    SDL_Surface *image_block_khali = SDL_LoadBMP("block_khali.bmp");
    if (!image_block_khali)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texture_block_khali = SDL_CreateTextureFromSurface(renderer, image_block_khali);

    Mix_PlayMusic(music,-1);
    while (game_is_running) {
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        SDL_ShowCursor(SDL_DISABLE);
        render_blocks(number_of_block,arr_of_colors,arr_of_block,texture_block_khali,texture_block_por);
        soundplay();
        if(!sound)
            Mix_PauseMusic();
        else
            Mix_ResumeMusic();
        showcursor();
        SDL_RenderPresent(renderer);
        check_exit_game();
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    Mix_Quit();
    SDL_Quit();
}
int first_page()
{
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,2,2048) < 0)
        printf("%s",Mix_GetError());
    Mix_Music *music= Mix_LoadMUS("music_first.mp3");
    if (!is_ok_to_run_game())
        return -1;
    window = SDL_CreateWindow("HELLO", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH,
                              SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    SDL_SetWindowBordered(window, SDL_WINDOW_FULLSCREEN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    image = SDL_LoadBMP("bf4.bmp");
    if (!image)
        printf("ridi %s", SDL_GetError());
    texture = SDL_CreateTextureFromSurface(renderer, image);

    SDL_Surface *imagegame = SDL_LoadBMP("gamename.bmp");
    if (!imagegame)
        printf("ridi %s", SDL_GetError());
    SDL_Texture *texturegame = SDL_CreateTextureFromSurface(renderer, imagegame);
    int tool=imagegame->w / 4;
    int arz=imagegame->h  / 4;
    int temp99=0;
    int centerx=960;
    int centery=650;
    Mix_PlayMusic(music,-1);
    while (game_is_running) {
        SDL_Rect temp_rect;
        while(tool < imagegame->w /2 && game_is_running)
        {
            SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
            show_text(renderer,30,30,"LOADING PLEASE WAIT ..",60,0,0,0,255);
            temp_rect.x=centerx-tool/2;
            temp_rect.y=centery-arz/2;
            temp_rect.w=tool;
            temp_rect.h=arz;
            tool+=1;
            arz+=1;
            SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
            SDL_RenderPresent(renderer);
            check_exit_game();
            SDL_RenderClear(renderer);
        }
        while(game_is_running && temp99<255)
        {
            SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
            show_text(renderer, 30, 30, "PLEASE ENTER YOUR NAME :", 40, 40, 2, 90, temp99);
            SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
            soundplay();
            if(!sound)
                Mix_PauseMusic();
            else
                Mix_ResumeMusic();
            SDL_ShowCursor(SDL_DISABLE);
            showcursor();
            SDL_RenderPresent(renderer);
            check_exit_game();
            SDL_RenderClear(renderer);
            temp99+=2;
        }
        SDL_RenderCopy(renderer, texture, NULL, &texture_rect);
        SDL_RenderCopy(renderer, texturegame, NULL, &temp_rect);
        show_text(renderer, 30, 30, "PLEASE ENTER YOUR NAME :", 40, 40, 2, 90, 255);
        soundplay();
        if(!sound)
            Mix_PauseMusic();
        else
            Mix_ResumeMusic();
        SDL_ShowCursor(SDL_DISABLE);
        showcursor();
        SDL_RenderPresent(renderer);
        check_exit_game();
        SDL_Delay(1000 / FPS);
        SDL_RenderClear(renderer);
    }
    window = NULL;
    renderer = NULL;
    texture=NULL;
    image=NULL;
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    Mix_FreeMusic(music);
    Mix_Quit();
    SDL_Quit();
}
int main()
{
    first_page();
 //   menu();
 //   map();
    return 0;
}